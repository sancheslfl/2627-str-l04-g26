/* mbed Microcontroller Library
 * Copyright (c) 2006-2012 ARM Limited
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
#ifndef MBED_CMSIS_CONF_H
#define MBED_CMSIS_CONF_H

#ifndef MBED_CONF_TZ_PROCESS_STACK_SIZE
#define MBED_CONF_TZ_PROCESS_STACK_SIZE  512
#endif
#ifndef MBED_CONF_TZ_PROCESS_STACK_SLOTS
#define MBED_CONF_TZ_PROCESS_STACK_SLOTS  8
#endif

#define TZ_PROCESS_STACK_SLOTS  MBED_CONF_TZ_PROCESS_STACK_SLOTS
#define TZ_PROCESS_STACK_SIZE  MBED_CONF_TZ_PROCESS_STACK_SIZE

#endif /* MBED_CMSIS_CONF_H */
