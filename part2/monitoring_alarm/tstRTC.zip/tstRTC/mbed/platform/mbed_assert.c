/* mbed Microcontroller Library
 * Copyright (c) 2006-2013 ARM Limited
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#include "platform/mbed_assert.h"
#include "device.h"

#include "platform/mbed_interface.h"
#include "platform/mbed_critical.h"

void mbed_assert_internal(const char *expr, const char *file, int line)
{
    core_util_critical_section_enter();
    mbed_error_printf("mbed assertation failed: %s, file: %s, line %d \n", expr, file, line);
    mbed_die();
}
